package FactoryMethodPROF;


public class Circulo implements Iforma {

    @Override
    public void desenhar() {
        System.out.println("Circulo");
    }
}
