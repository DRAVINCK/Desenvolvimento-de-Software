package FactoryMethodPROF;

public interface Iforma {
    void desenhar();

}
