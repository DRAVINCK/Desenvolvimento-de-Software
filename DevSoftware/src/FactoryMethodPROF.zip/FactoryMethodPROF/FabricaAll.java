package FactoryMethodPROF;


public class FabricaAll {


}
