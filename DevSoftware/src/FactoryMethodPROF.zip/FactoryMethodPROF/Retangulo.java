package FactoryMethodPROF;


public class Retangulo implements Iforma {


    @Override
    public void desenhar() {
        System.out.println("Retangulo");;
    }
}
