package FactoryMethodPROF;


public interface IfabricaFormas {
    Iforma criarForma();


}
