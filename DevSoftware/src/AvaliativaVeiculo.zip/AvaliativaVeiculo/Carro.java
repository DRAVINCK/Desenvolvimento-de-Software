package AvaliativaVeiculo;

import java.util.Date;

public class Carro implements Veiculo{


    public int NumPortas;
    @Override
    public void Marca() {

    }

    @Override
    public void Modelo() {

    }

    @Override
    public String AnoFabricacao() {
        return "";
    }

    @Override
    public double Preco() {

        return 0;
    }
}
