package AvaliativaVeiculo;

public interface Veiculo {
    public void Marca();

    public void Modelo();

    public String AnoFabricacao();

    public double Preco();

}
