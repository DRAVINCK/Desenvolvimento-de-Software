package AvaliativaVeiculo;

public class Motocicleta implements Veiculo{


    public double Cilindradas;
    @Override
    public void Marca() {

    }

    @Override
    public void Modelo() {

    }

    @Override
    public String AnoFabricacao() {
        return "";
    }

    @Override
    public double Preco() {

        return 0;
    }
}
