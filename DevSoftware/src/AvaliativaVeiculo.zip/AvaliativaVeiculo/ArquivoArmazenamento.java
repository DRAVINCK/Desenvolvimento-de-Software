package AvaliativaVeiculo;

public class ArquivoArmazenamento implements Armazenamento{

    @Override
    public void salvarDados(String veiculo) {

    }

    @Override
    public String recuperarDados() {
        return null;
    }
}
